using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using RegistrationService;
using System.Text.Json;

namespace DuelSimulation.Controllers;

[Route("DuelSimulation")]
public class DuelSimulationController : Controller {}

//Klasse leer, da alles in der BgService läuft (DuelBgSerive.cs)